@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.metacto.caching.datasource.database.sqldelight

import kotlin.Long
import kotlin.String

public data class ListData(
  public val apiUrl: String,
  public val modelVersion: Long,
  public val modelType: String,
  public val content: String,
)
