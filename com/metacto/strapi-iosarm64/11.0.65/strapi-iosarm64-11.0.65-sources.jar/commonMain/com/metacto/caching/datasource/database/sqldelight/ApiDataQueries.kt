@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.metacto.caching.datasource.database.sqldelight

import app.cash.sqldelight.Query
import app.cash.sqldelight.SuspendingTransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String
import kotlin.collections.Collection

public class ApiDataQueries(
  driver: SqlDriver,
) : SuspendingTransacterImpl(driver) {
  public fun <T : Any> getListDataByModelVersionAndApiUrl(
    modelVersion: Long,
    apiUrl: String,
    mapper: (
      apiUrl: String,
      modelVersion: Long,
      modelType: String,
      content: String,
    ) -> T,
  ): Query<T> = GetListDataByModelVersionAndApiUrlQuery(modelVersion, apiUrl) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getLong(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!
    )
  }

  public fun getListDataByModelVersionAndApiUrl(modelVersion: Long, apiUrl: String): Query<ListData> = getListDataByModelVersionAndApiUrl(modelVersion, apiUrl, ::ListData)

  public fun <T : Any> getListDataByModelVersionAndModelType(
    modelVersion: Long,
    modelType: String,
    mapper: (
      apiUrl: String,
      modelVersion: Long,
      modelType: String,
      content: String,
    ) -> T,
  ): Query<T> = GetListDataByModelVersionAndModelTypeQuery(modelVersion, modelType) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getLong(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!
    )
  }

  public fun getListDataByModelVersionAndModelType(modelVersion: Long, modelType: String): Query<ListData> = getListDataByModelVersionAndModelType(modelVersion, modelType, ::ListData)

  public fun <T : Any> getListDataByApiUrl(apiUrl: String, mapper: (
    apiUrl: String,
    modelVersion: Long,
    modelType: String,
    content: String,
  ) -> T): Query<T> = GetListDataByApiUrlQuery(apiUrl) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getLong(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!
    )
  }

  public fun getListDataByApiUrl(apiUrl: String): Query<ListData> = getListDataByApiUrl(apiUrl, ::ListData)

  public fun <T : Any> getListDataByModelType(modelType: String, mapper: (
    apiUrl: String,
    modelVersion: Long,
    modelType: String,
    content: String,
  ) -> T): Query<T> = GetListDataByModelTypeQuery(modelType) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getLong(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!
    )
  }

  public fun getListDataByModelType(modelType: String): Query<ListData> = getListDataByModelType(modelType, ::ListData)

  public fun <T : Any> getContentDataByModelVersionAndModelType(
    modelVersion: Long?,
    modelType: String?,
    mapper: (
      modelId: Long?,
      modelType: String?,
      modelVersion: Long?,
      content: String?,
      apiUrl: String?,
    ) -> T,
  ): Query<T> = GetContentDataByModelVersionAndModelTypeQuery(modelVersion, modelType) { cursor ->
    mapper(
      cursor.getLong(0),
      cursor.getString(1),
      cursor.getLong(2),
      cursor.getString(3),
      cursor.getString(4)
    )
  }

  public fun getContentDataByModelVersionAndModelType(modelVersion: Long?, modelType: String?): Query<ContentData> = getContentDataByModelVersionAndModelType(modelVersion, modelType, ::ContentData)

  public fun <T : Any> getContentDataByModelVersionAndModelTypeAndApiUrl(
    modelVersion: Long?,
    modelType: String?,
    apiUrl: String?,
    mapper: (
      modelId: Long?,
      modelType: String?,
      modelVersion: Long?,
      content: String?,
      apiUrl: String?,
    ) -> T,
  ): Query<T> = GetContentDataByModelVersionAndModelTypeAndApiUrlQuery(modelVersion, modelType, apiUrl) { cursor ->
    mapper(
      cursor.getLong(0),
      cursor.getString(1),
      cursor.getLong(2),
      cursor.getString(3),
      cursor.getString(4)
    )
  }

  public fun getContentDataByModelVersionAndModelTypeAndApiUrl(
    modelVersion: Long?,
    modelType: String?,
    apiUrl: String?,
  ): Query<ContentData> = getContentDataByModelVersionAndModelTypeAndApiUrl(modelVersion, modelType, apiUrl, ::ContentData)

  public fun <T : Any> getContentDataByModelVersionAndApiUrl(
    modelVersion: Long?,
    apiUrl: String?,
    mapper: (
      modelId: Long?,
      modelType: String?,
      modelVersion: Long?,
      content: String?,
      apiUrl: String?,
    ) -> T,
  ): Query<T> = GetContentDataByModelVersionAndApiUrlQuery(modelVersion, apiUrl) { cursor ->
    mapper(
      cursor.getLong(0),
      cursor.getString(1),
      cursor.getLong(2),
      cursor.getString(3),
      cursor.getString(4)
    )
  }

  public fun getContentDataByModelVersionAndApiUrl(modelVersion: Long?, apiUrl: String?): Query<ContentData> = getContentDataByModelVersionAndApiUrl(modelVersion, apiUrl, ::ContentData)

  public fun <T : Any> getContentDataByModelType(modelType: String?, mapper: (
    modelId: Long?,
    modelType: String?,
    modelVersion: Long?,
    content: String?,
    apiUrl: String?,
  ) -> T): Query<T> = GetContentDataByModelTypeQuery(modelType) { cursor ->
    mapper(
      cursor.getLong(0),
      cursor.getString(1),
      cursor.getLong(2),
      cursor.getString(3),
      cursor.getString(4)
    )
  }

  public fun getContentDataByModelType(modelType: String?): Query<ContentData> = getContentDataByModelType(modelType, ::ContentData)

  public fun <T : Any> getContentDataByApiUrl(apiUrl: String?, mapper: (
    modelId: Long?,
    modelType: String?,
    modelVersion: Long?,
    content: String?,
    apiUrl: String?,
  ) -> T): Query<T> = GetContentDataByApiUrlQuery(apiUrl) { cursor ->
    mapper(
      cursor.getLong(0),
      cursor.getString(1),
      cursor.getLong(2),
      cursor.getString(3),
      cursor.getString(4)
    )
  }

  public fun getContentDataByApiUrl(apiUrl: String?): Query<ContentData> = getContentDataByApiUrl(apiUrl, ::ContentData)

  public fun <T : Any> getContentDataByModelTypeAndModelVersionAndModelIds(
    modelType: String?,
    modelVersion: Long?,
    modelId: Collection<Long?>,
    mapper: (
      modelId: Long?,
      modelType: String?,
      modelVersion: Long?,
      content: String?,
      apiUrl: String?,
    ) -> T,
  ): Query<T> = GetContentDataByModelTypeAndModelVersionAndModelIdsQuery(modelType, modelVersion, modelId) { cursor ->
    mapper(
      cursor.getLong(0),
      cursor.getString(1),
      cursor.getLong(2),
      cursor.getString(3),
      cursor.getString(4)
    )
  }

  public fun getContentDataByModelTypeAndModelVersionAndModelIds(
    modelType: String?,
    modelVersion: Long?,
    modelId: Collection<Long?>,
  ): Query<ContentData> = getContentDataByModelTypeAndModelVersionAndModelIds(modelType, modelVersion, modelId, ::ContentData)

  public fun <T : Any> getContentDataByModelTypeAndModelVersionAndModelId(
    modelType: String?,
    modelVersion: Long?,
    modelId: Long?,
    mapper: (
      modelId: Long?,
      modelType: String?,
      modelVersion: Long?,
      content: String?,
      apiUrl: String?,
    ) -> T,
  ): Query<T> = GetContentDataByModelTypeAndModelVersionAndModelIdQuery(modelType, modelVersion, modelId) { cursor ->
    mapper(
      cursor.getLong(0),
      cursor.getString(1),
      cursor.getLong(2),
      cursor.getString(3),
      cursor.getString(4)
    )
  }

  public fun getContentDataByModelTypeAndModelVersionAndModelId(
    modelType: String?,
    modelVersion: Long?,
    modelId: Long?,
  ): Query<ContentData> = getContentDataByModelTypeAndModelVersionAndModelId(modelType, modelVersion, modelId, ::ContentData)

  /**
   * @return The number of rows updated.
   */
  public suspend fun insertOrUpdateListData(
    apiUrl: String,
    modelVersion: Long,
    modelType: String,
    content: String,
  ): Long {
    val result = driver.execute(-1_651_686_937, """INSERT OR REPLACE INTO listData (apiUrl, modelVersion, modelType, content) VALUES (?, ?, ?, ?)""", 4) {
          var parameterIndex = 0
          bindString(parameterIndex++, apiUrl)
          bindLong(parameterIndex++, modelVersion)
          bindString(parameterIndex++, modelType)
          bindString(parameterIndex++, content)
        }.await()
    notifyQueries(-1_651_686_937) { emit ->
      emit("listData")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public suspend fun deleteListDataByModelVersionAndApiUrl(modelVersion: Long, apiUrl: String): Long {
    val result = driver.execute(1_888_302_329, """DELETE FROM listData WHERE modelVersion = ? AND apiUrl = ?""", 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modelVersion)
          bindString(parameterIndex++, apiUrl)
        }.await()
    notifyQueries(1_888_302_329) { emit ->
      emit("listData")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public suspend fun deleteListDataByApiUrl(apiUrl: String): Long {
    val result = driver.execute(214_419_577, """DELETE FROM listData WHERE apiUrl = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, apiUrl)
        }.await()
    notifyQueries(214_419_577) { emit ->
      emit("listData")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public suspend fun insertOrUpdateContentData(
    modelId: Long?,
    modelType: String?,
    modelVersion: Long?,
    content: String?,
    apiUrl: String?,
  ): Long {
    val result = driver.execute(-110_017_820, """INSERT OR REPLACE INTO contentData (modelId, modelType, modelVersion, content, apiUrl) VALUES (?, ?, ?, ?, ?)""", 5) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modelId)
          bindString(parameterIndex++, modelType)
          bindLong(parameterIndex++, modelVersion)
          bindString(parameterIndex++, content)
          bindString(parameterIndex++, apiUrl)
        }.await()
    notifyQueries(-110_017_820) { emit ->
      emit("contentData")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public suspend fun deleteContentDataByModelVersionAndModelType(modelVersion: Long?, modelType: String?): Long {
    val result = driver.execute(null, """DELETE FROM contentData WHERE modelVersion ${ if (modelVersion == null) "IS" else "=" } ? AND modelType ${ if (modelType == null) "IS" else "=" } ?""", 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modelVersion)
          bindString(parameterIndex++, modelType)
        }.await()
    notifyQueries(1_396_641_008) { emit ->
      emit("contentData")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public suspend fun deleteContentDataByModelVersionAndApiUrl(modelVersion: Long?, apiUrl: String?): Long {
    val result = driver.execute(null, """DELETE FROM contentData WHERE modelVersion ${ if (modelVersion == null) "IS" else "=" } ? AND apiUrl ${ if (apiUrl == null) "IS" else "=" } ?""", 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modelVersion)
          bindString(parameterIndex++, apiUrl)
        }.await()
    notifyQueries(2_120_698_152) { emit ->
      emit("contentData")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public suspend fun deleteContentDataByModelType(modelType: String?): Long {
    val result = driver.execute(null, """DELETE FROM contentData WHERE modelType ${ if (modelType == null) "IS" else "=" } ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, modelType)
        }.await()
    notifyQueries(-1_553_292_626) { emit ->
      emit("contentData")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public suspend fun deleteContentDataByApiUrl(apiUrl: String?): Long {
    val result = driver.execute(null, """DELETE FROM contentData WHERE apiUrl ${ if (apiUrl == null) "IS" else "=" } ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, apiUrl)
        }.await()
    notifyQueries(-1_929_135_062) { emit ->
      emit("contentData")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public suspend fun deleteContentDataByModelIdAndModelType(modelId: Long?, modelType: String?): Long {
    val result = driver.execute(null, """DELETE FROM contentData WHERE modelId ${ if (modelId == null) "IS" else "=" } ? AND modelType ${ if (modelType == null) "IS" else "=" } ?""", 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modelId)
          bindString(parameterIndex++, modelType)
        }.await()
    notifyQueries(-857_084_645) { emit ->
      emit("contentData")
    }
    return result
  }

  private inner class GetListDataByModelVersionAndApiUrlQuery<out T : Any>(
    public val modelVersion: Long,
    public val apiUrl: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("listData", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("listData", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(2_107_303_970, """SELECT listData.apiUrl, listData.modelVersion, listData.modelType, listData.content FROM listData WHERE modelVersion = ? AND apiUrl = ?""", mapper, 2) {
      var parameterIndex = 0
      bindLong(parameterIndex++, modelVersion)
      bindString(parameterIndex++, apiUrl)
    }

    override fun toString(): String = "ApiData.sq:getListDataByModelVersionAndApiUrl"
  }

  private inner class GetListDataByModelVersionAndModelTypeQuery<out T : Any>(
    public val modelVersion: Long,
    public val modelType: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("listData", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("listData", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_802_523_574, """SELECT listData.apiUrl, listData.modelVersion, listData.modelType, listData.content FROM listData WHERE modelVersion = ? AND modelType = ?""", mapper, 2) {
      var parameterIndex = 0
      bindLong(parameterIndex++, modelVersion)
      bindString(parameterIndex++, modelType)
    }

    override fun toString(): String = "ApiData.sq:getListDataByModelVersionAndModelType"
  }

  private inner class GetListDataByApiUrlQuery<out T : Any>(
    public val apiUrl: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("listData", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("listData", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-362_198_928, """SELECT listData.apiUrl, listData.modelVersion, listData.modelType, listData.content FROM listData WHERE apiUrl = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, apiUrl)
    }

    override fun toString(): String = "ApiData.sq:getListDataByApiUrl"
  }

  private inner class GetListDataByModelTypeQuery<out T : Any>(
    public val modelType: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("listData", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("listData", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_336_502_440, """SELECT listData.apiUrl, listData.modelVersion, listData.modelType, listData.content FROM listData WHERE modelType = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, modelType)
    }

    override fun toString(): String = "ApiData.sq:getListDataByModelType"
  }

  private inner class GetContentDataByModelVersionAndModelTypeQuery<out T : Any>(
    public val modelVersion: Long?,
    public val modelType: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("contentData", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("contentData", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT contentData.modelId, contentData.modelType, contentData.modelVersion, contentData.content, contentData.apiUrl FROM contentData WHERE modelVersion ${ if (modelVersion == null) "IS" else "=" } ? AND modelType ${ if (modelType == null) "IS" else "=" } ?""", mapper, 2) {
      var parameterIndex = 0
      bindLong(parameterIndex++, modelVersion)
      bindString(parameterIndex++, modelType)
    }

    override fun toString(): String = "ApiData.sq:getContentDataByModelVersionAndModelType"
  }

  private inner class GetContentDataByModelVersionAndModelTypeAndApiUrlQuery<out T : Any>(
    public val modelVersion: Long?,
    public val modelType: String?,
    public val apiUrl: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("contentData", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("contentData", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT contentData.modelId, contentData.modelType, contentData.modelVersion, contentData.content, contentData.apiUrl FROM contentData WHERE modelVersion ${ if (modelVersion == null) "IS" else "=" } ? AND modelType ${ if (modelType == null) "IS" else "=" } ? AND apiUrl ${ if (apiUrl == null) "IS" else "=" } ?""", mapper, 3) {
      var parameterIndex = 0
      bindLong(parameterIndex++, modelVersion)
      bindString(parameterIndex++, modelType)
      bindString(parameterIndex++, apiUrl)
    }

    override fun toString(): String = "ApiData.sq:getContentDataByModelVersionAndModelTypeAndApiUrl"
  }

  private inner class GetContentDataByModelVersionAndApiUrlQuery<out T : Any>(
    public val modelVersion: Long?,
    public val apiUrl: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("contentData", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("contentData", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT contentData.modelId, contentData.modelType, contentData.modelVersion, contentData.content, contentData.apiUrl FROM contentData WHERE modelVersion ${ if (modelVersion == null) "IS" else "=" } ? AND apiUrl ${ if (apiUrl == null) "IS" else "=" } ?""", mapper, 2) {
      var parameterIndex = 0
      bindLong(parameterIndex++, modelVersion)
      bindString(parameterIndex++, apiUrl)
    }

    override fun toString(): String = "ApiData.sq:getContentDataByModelVersionAndApiUrl"
  }

  private inner class GetContentDataByModelTypeQuery<out T : Any>(
    public val modelType: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("contentData", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("contentData", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT contentData.modelId, contentData.modelType, contentData.modelVersion, contentData.content, contentData.apiUrl FROM contentData WHERE modelType ${ if (modelType == null) "IS" else "=" } ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, modelType)
    }

    override fun toString(): String = "ApiData.sq:getContentDataByModelType"
  }

  private inner class GetContentDataByApiUrlQuery<out T : Any>(
    public val apiUrl: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("contentData", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("contentData", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT contentData.modelId, contentData.modelType, contentData.modelVersion, contentData.content, contentData.apiUrl FROM contentData WHERE apiUrl ${ if (apiUrl == null) "IS" else "=" } ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, apiUrl)
    }

    override fun toString(): String = "ApiData.sq:getContentDataByApiUrl"
  }

  private inner class GetContentDataByModelTypeAndModelVersionAndModelIdsQuery<out T : Any>(
    public val modelType: String?,
    public val modelVersion: Long?,
    public val modelId: Collection<Long?>,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("contentData", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("contentData", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> {
      val modelIdIndexes = createArguments(count = modelId.size)
      return driver.executeQuery(null, """SELECT contentData.modelId, contentData.modelType, contentData.modelVersion, contentData.content, contentData.apiUrl FROM contentData WHERE modelType ${ if (modelType == null) "IS" else "=" } ? AND modelVersion ${ if (modelVersion == null) "IS" else "=" } ? AND modelId IN $modelIdIndexes""", mapper, 2 + modelId.size) {
            var parameterIndex = 0
            bindString(parameterIndex++, modelType)
            bindLong(parameterIndex++, modelVersion)
            modelId.forEach { modelId_ ->
              bindLong(parameterIndex++, modelId_)
            }
          }
    }

    override fun toString(): String = "ApiData.sq:getContentDataByModelTypeAndModelVersionAndModelIds"
  }

  private inner class GetContentDataByModelTypeAndModelVersionAndModelIdQuery<out T : Any>(
    public val modelType: String?,
    public val modelVersion: Long?,
    public val modelId: Long?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("contentData", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("contentData", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT contentData.modelId, contentData.modelType, contentData.modelVersion, contentData.content, contentData.apiUrl FROM contentData WHERE modelType ${ if (modelType == null) "IS" else "=" } ? AND modelVersion ${ if (modelVersion == null) "IS" else "=" } ? AND modelId ${ if (modelId == null) "IS" else "=" } ?""", mapper, 3) {
      var parameterIndex = 0
      bindString(parameterIndex++, modelType)
      bindLong(parameterIndex++, modelVersion)
      bindLong(parameterIndex++, modelId)
    }

    override fun toString(): String = "ApiData.sq:getContentDataByModelTypeAndModelVersionAndModelId"
  }
}
