@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.metacto.caching.datasource.database.strapi

import app.cash.sqldelight.SuspendingTransacterImpl
import app.cash.sqldelight.db.AfterVersion
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.metacto.caching.datasource.database.AppDatabase
import com.metacto.caching.datasource.database.sqldelight.ApiDataQueries
import kotlin.Long
import kotlin.Unit
import kotlin.reflect.KClass

internal val KClass<AppDatabase>.schema: SqlSchema<QueryResult.AsyncValue<Unit>>
  get() = AppDatabaseImpl.Schema

internal fun KClass<AppDatabase>.newInstance(driver: SqlDriver): AppDatabase = AppDatabaseImpl(driver)

private class AppDatabaseImpl(
  driver: SqlDriver,
) : SuspendingTransacterImpl(driver),
    AppDatabase {
  override val apiDataQueries: ApiDataQueries = ApiDataQueries(driver)

  public object Schema : SqlSchema<QueryResult.AsyncValue<Unit>> {
    override val version: Long
      get() = 1

    override fun create(driver: SqlDriver): QueryResult.AsyncValue<Unit> = QueryResult.AsyncValue {
      driver.execute(null, """
          |CREATE TABLE listData (
          |    apiUrl TEXT NOT NULL PRIMARY KEY ON CONFLICT REPLACE,
          |    modelVersion INTEGER NOT NULL,
          |    modelType TEXT NOT NULL,
          |    content TEXT NOT NULL -- Ids of the list items so we can fetch them from the contentDataTable based on the modelType
          |)
          """.trimMargin(), 0).await()
      driver.execute(null, """
          |CREATE TABLE contentData (
          |    modelId INTEGER,
          |    modelType TEXT,
          |    modelVersion INTEGER,
          |    content TEXT,
          |    apiUrl TEXT UNIQUE ON CONFLICT REPLACE, -- In case of modelType cannot be determined and also the modelId so we will fetch using the apiUrl
          |    PRIMARY KEY (modelId, modelType) ON CONFLICT REPLACE
          |)
          """.trimMargin(), 0).await()
    }

    override fun migrate(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
      vararg callbacks: AfterVersion,
    ): QueryResult.AsyncValue<Unit> = QueryResult.AsyncValue {
    }
  }
}
