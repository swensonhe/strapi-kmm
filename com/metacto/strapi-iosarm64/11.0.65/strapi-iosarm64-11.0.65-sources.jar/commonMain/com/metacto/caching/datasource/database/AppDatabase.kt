@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.metacto.caching.datasource.database

import app.cash.sqldelight.SuspendingTransacter
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.metacto.caching.datasource.database.sqldelight.ApiDataQueries
import com.metacto.caching.datasource.database.strapi.newInstance
import com.metacto.caching.datasource.database.strapi.schema
import kotlin.String
import kotlin.Unit
import kotlin.collections.List

public interface AppDatabase : SuspendingTransacter {
  public val apiDataQueries: ApiDataQueries

  public companion object {
    public val Schema: SqlSchema<QueryResult.AsyncValue<Unit>>
      get() = AppDatabase::class.schema

    public operator fun invoke(driver: SqlDriver): AppDatabase = AppDatabase::class.newInstance(driver)

    public fun allTableNames(): List<String> = listOf("contentData", "listData")
  }
}
