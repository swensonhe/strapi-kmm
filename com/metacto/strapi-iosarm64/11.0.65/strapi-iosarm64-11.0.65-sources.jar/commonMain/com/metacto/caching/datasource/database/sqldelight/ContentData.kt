@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.metacto.caching.datasource.database.sqldelight

import kotlin.Long
import kotlin.String

public data class ContentData(
  public val modelId: Long?,
  public val modelType: String?,
  public val modelVersion: Long?,
  public val content: String?,
  public val apiUrl: String?,
)
